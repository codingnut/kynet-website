
export default {
  MODULE:      'module',
  MODULE_ITEM: 'module_item',
};
